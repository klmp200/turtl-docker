# [Contributing to Turtl](https://turtl.it/contributing/)

Thanks for wanting to help make the Turtl project better!

If you're submitting an issue, please carry on. No need to read the contributing
guidlines. However, you may be interested in [our Trello list](https://trello.com/b/yIQGkHia/turtl-product-dev).

If you're opening a pull request or wanting to contribute code, please see our
[page on contributing to Turtl](https://turtl.it/contributing/) to get started.

